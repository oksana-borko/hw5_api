import {launchServer} from "./server.ts";


launchServer();