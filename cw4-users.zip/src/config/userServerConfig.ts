
export const PORT = 3005;
export const baseUrl = `http://localhost:${PORT}`;