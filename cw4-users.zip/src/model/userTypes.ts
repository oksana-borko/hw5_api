
export interface User  {
    id:number,
    userName: string
}